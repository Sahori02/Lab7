<?php
/**
 * Created by PhpStorm.
 * User: profb
 * Date: 11/08/2020
 * Time: 7:11 AM
 */
phpinfo();